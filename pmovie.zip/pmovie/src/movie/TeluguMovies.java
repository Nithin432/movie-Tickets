package movie;

import java.util.Scanner;

public interface TeluguMovies
{
	default void tmovies()
	{
		Scanner s=new Scanner(System.in);
	    int a=1;
	    String arr1[]= {"1.hanu-man","2.salaar","3.eagle","4.milleer","5.guntur_karam","6.yatra2","7.naa-saamiranga"};
		System.out.println("telugu movies are at present in thraters");
		for(String mn:arr1)
		{
			System.out.println(mn);
		}
	    int mtname=s.nextInt();
	    while(a<8)
	     {
	    	 if(mtname==a)
	    	 {
	    		new Stages().stages();;
	    	 }
	    	 else
	    	 {
	    		 a++;
	    	 }
	     }
	     if(a>=8)
	     {
	    	 System.out.println("invaild input ");
	    	 tmovies(); 
	     }
	     s.close();
	}
   
}
