package movie;

import java.util.Scanner;

public class Stages extends Billing
{
	 static int i=1;
     static int tickes;
     static int count;
    
void stages()
  {
		Scanner s=new Scanner(System.in);
		 int n;
	     for(;i==1;i++)
	     {	
	        System.out.println("select the seats for platinum 250 rs ,for gold 150, for silver 50");
	        System.out.println("press '1' for platinum , press '2'for gold , press '3' for silver");
	        int a=s.nextInt();
	         switch(a)
	          {
	             case 1: 
	             System.out.println("you select platinum");
	             System.out.println("if you want to continue platinum press '1' or you want select others press '2'");
	             n=s.nextInt();
	             if(n==1)
	             {
	            	final int amount=250;
	            	System.out.println("enter the no of tickes do you want");
	            	tickes=s.nextInt();
	            	count=tickes*amount;
	            	System.out.println("you selected no of tickes is "+tickes+"for that your amount is "+count);
	            	billing();
	            	i++;
	             }
	             else if (n==2)
	             {
	            	i--;
	            	break;
	             } 
	             else 
	             {
	            	 System.out.println("invalid input select the correct option");
	            	 stages();
	             }
	             break;
	             case 2: 
	             System.out.println("you select gold");
	             System.out.println("if you want to continue gold press '1' or you want select others press '2'");
	             n=s.nextInt();
	             if(n==1)
	             {
	            	 int amount=150;
	             	System.out.println("enter the no of tickes do you want");
	             	tickes=s.nextInt();
	             	count=tickes*amount;
	             	System.out.println("you selected no of tickes is"+tickes+"for that your amount is"+count);
	             	billing();
	             	
	             }
	             else if (n==2)
	             {
	            	i--;
	            	break;
	             } 
	             else 
	             {
	            	 System.out.println("invalid input select the correct option");
	            	 stages();
	             }
	             break;
	             case 3: 
	             System.out.println("you select silver");
	             System.out.println("if you want to continue silver press '1' or you want select others press '2'");
	             n=s.nextInt();
	             if(n==1)
	               {
	            	 int amount=50;
	             	System.out.println("enter how many tickes do you want to book");
	             	tickes=s.nextInt();
	             	count=tickes*amount;
	             	System.out.println("you selected no of tickes is"+tickes+"for that your amount is"+count);
	             	billing();;
	             	
	               }
	             else if (n==2)
	               {
	              	i--;
	               	break;
	               } 
	             else 
	               {
	               	 System.out.println("invalid input select the correct option");
	               	 stages();
	               }
	             break;
	             default : System.out.println("invalid input ");
	             stages();
	          }
	         
	  	   s.close();

	     }
  }
    public int getTickes()
    {
	return tickes;
	}
}
