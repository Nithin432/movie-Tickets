package movie;

import java.util.Scanner;

public interface Marvels 
{
  default void marvels()
  {
		Scanner s=new Scanner(System.in);
	    int a=1;
	    String arr2[]= {"1.ironman","2.capapion_american","3.averanges","4.loki","5.batman"};
		System.out.println("marvels movies are at present in thraters");
		for(String mm:arr2)
		{
			System.out.println(mm);
		}
		int mmname=s.nextInt();
	     while(a<8)
	     {
	    	 if(mmname==a)
	    	 {
	    		new Stages().stages();;
	    	 }
	    	 else
	    	 {
	    		 a++;
	    	 }
	     }
	     if(a>=8)
	     {
	    	 System.out.println("invaild input ");
	    	 marvels(); 
	     }
	     s.close();
  }
  
}
