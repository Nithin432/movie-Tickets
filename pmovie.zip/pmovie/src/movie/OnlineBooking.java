package movie;
import java.util.*;

public class OnlineBooking extends movieLag
{
	Scanner s=new Scanner(System.in);
	static int i=1;
    static int theater;
    public void BookTickets()
    {
        for(;i==1;i++)
        {
        	System.out.println("select the location near by you to book the tickes");
        	System.out.println("1.Khairtabad,");
        	System.out.println("2.ameerpet,");
        	System.out.println("3.RTC_X_Roads,");
        	System.out.println("4.Panjagutta,");
        	System.out.println("5.Gachibowli, ");
        	System.out.println("6.Moosapet,");
        	System.out.println("7.Miyapur. ");
        	System.out.println("enter any the loction number");
        	int location=s.nextInt();
        switch(location)
        { 
        case 1:
    		System.out.println("select theaters");
            System.	out.println("1.prasads-multiplex");
    		System.out.println("2.sensation insomina");
    		theater=s.nextInt();
    		if(theater==1 || theater==2)
    		{
               lang();
    		}
    		else
    		{
    			System.out.println("invalid input");
    			i--;
    			
    		}
        break;
        case 2 :
        	
        		System.out.println("select theaters");
        		System.out.println("1.AAA");
        		System.out.println("2.carnival");
        		theater=s.nextInt();
        		if(theater==1 || theater==2)
        		{
            	 lang();
        		}
        		else
        		{
        			System.out.println("invalid input");
        			i--;
        			        		}

        break;
        case 3: 
        	{
        		System.out.println("select theaters");
        		System.out.println("1.sandaya");
        		System.out.println("2.saptaira");
        		System.out.println("3.sudarshan");
        		theater=s.nextInt();
        		if(theater==1 || theater==2 || theater==3)
        		{
            		lang();
        		}
        		else
        		{
        			System.out.println("invalid input");
        			i--;
        			
        		}

        	}
        break;
        case 4 : 
        	{
        		System.out.println("select theaters");
        		System.out.println("1.pvr:Next Galleria mall ");
        		System.out.println("2.pvr:center mall");
        		theater=s.nextInt();
        		if(theater==1 || theater==2)
        		{
            		lang();
        		}
        		else
        		{
        			System.out.println("invalid input");
        			i--;
        			
        		}

        	}
        break;
        case 5:
        	{
        		System.out.println("select theaters");
        		System.out.println("1.AMB");
        		System.out.println("2.pvr preston prime");
        		System.out.println("3.platium cinema");
        		theater=s.nextInt();
        		if(theater==1 || theater==2 || theater==3)
        		{
        	       lang();
        		}
        		else
        		{
        			System.out.println("invalid input");
        			i--;
        			
        		}

        	}
        break;
        case 6 : 
        	{
        		System.out.println("select theaters");
        		System.out.println("1.sree ramulu");
        		System.out.println("2.asian laxshmikala");
        		theater=s.nextInt();
        		if(theater==1 || theater==2)
        		{
            		lang();;
        		}
        		else
        		{
        			System.out.println("invalid input");
        			i--;
        			
        		}

        	}
        break;
        case 7: 
        	{
        		System.out.println("select theaters");
        		System.out.println("1.miraj cinemas");
        		System.out.println("2.sai ranga ");
        		System.out.println("3.cinetown");
        		theater=s.nextInt();
        		if(theater==1 || theater==2 || theater==3)
        		{
            		lang();
        		}
        		else
        		{
        			System.out.println("invalid input");
        			i--;
        			
        		}

        	}
        break;
        default :
        	System.out.println("wrong input selected");
        	i--;
        }
        }
    }
}


    