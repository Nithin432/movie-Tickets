package movie;

import java.util.Scanner;

public class movieLag implements TeluguMovies, Marvels, HindiMovie
   {
	void lang()
	{
 		Scanner s=new Scanner(System.in);
	System.out.println("choice the language to watch the movie");
	System.out.println("1.telugu movies");
	System.out.println("2.marvels movies");
	System.out.println("3.hindi movies");
	System.out.println("if you want to go main menu then press  4");
	int lang=s.nextInt();
	switch(lang)
	{
	case 1: tmovies();
		break;
	case 2: marvels();
	break;
	case 3:hmovies();
	break;
	case 4: new OnlineBooking().BookTickets();
	break;
	default : System.out.println("invuled input");
	lang();
	s.close();
	}
	}
}
