package movie;
import java.util.Scanner;
public interface HindiMovie 
{
    default void hmovies()
     {
 		Scanner s=new Scanner(System.in);
     	int a=1;
     	String arr1[]= {"1. tejas","2.IB71","3.Pathaan","4. mission Raniganj","5.Tanhaji"};
 		System.out.println("hindi movies are at present in thraters");
 		for(String hn:arr1)
 		{
 			System.out.println(hn);
 		}
 		int mhname=s.nextInt();
 	     while(a<8)
 	     {
 	    	 if(mhname==a)
 	    	 {
 	    		new Stages().stages();;
 	    	 }
 	    	 else
 	    	 {
 	    		 a++;
 	    	 }
 	     }
 	     if(a>=8)
 	     {
 	    	 System.out.println("invaild input ");
 	         hmovies(); 
 	     }
 	     s.close();
     }
     
}
