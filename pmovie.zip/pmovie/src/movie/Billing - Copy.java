package movie;
import java.util.Scanner;
public class Billing extends OnlineBooking
{
void billing()
{
	Scanner s=new Scanner(System.in);

	System.out.println("if you want continue to pesss '1' for billing"
			+ "press 2 for rebooking or press 3 for main menu");
	int conformTickes=s.nextInt();
	switch(conformTickes)
	{
	   case 1:
		
		int a= new Stages().getTickes();
		String name[]= new String[a];
		for(int b=0;b<=name.length-1;b++)
		{
			System.out.println("enter you"+a+"name");
			name[b]= s.next();	
		}
		System.out.println("your emailId:"); 
		String email=s.next();
		System.out.println("your phoneNo:");
		String phone=s.next();
		System.out.println();
		System.out.println("-                    movie ticket                    -");
		System.out.println("                    ==============                    ");
		System.out.println("\n");
		for(String i:name)
		{
		System.out.println("name:"+i);
	    }
		System.out.println("email:"+email);
		System.out.println("phone:"+phone);
		System.out.println("no of tickes:"+Stages.tickes);
		System.out.println("you are bill:"+Stages.count);
		int discount=(Stages.count*10)/100;
		System.out.println("you got 10% discount");
		System.out.println();
		System.out.println("======================================================");
		System.out.println("final amout:"+(Stages.count-discount));
		System.out.println("======================================================");
		break;
	case 2: new Stages().stages();
	break;
	case 3: BookTickets();
	break;
	default : 
		{System.out.println("invaild input ");
		new Stages().stages();
		}
	}
	s.close();
}     
	public static void main(String[] args)
	{
		System.out.println("!!  wellcome to movie world  @@");
		System.out.println("===============================");
		Logic ob=new Logic();
		ob.login();
		
	}
	

}

