package movie;

import java.util.Scanner;

public class Logic extends OnlineBooking
{
	Scanner s=new Scanner(System.in);
	String userName;
	String EnterPassword;
       
		public void login()
		{		
			System.out.println("press 1 for login & press 2 for reg");
			int a=s.nextInt();
			if(a==1)				
			{
			System.out.println("EnterUsername");
			String uName=s.next();
			
			System.out.println("enter password");		
			String pword=s.next();
			if(uName.equals(userName) && pword.equals(EnterPassword) )
			{
			System.out.println("welcome "+uName);
			BookTickets();
			}
			else
			{
				System.out.println("incorret username/password");
				this.login();
			}
			}
			else if(a==2)
				regester();
			else
				this.login();
		}
	
		public void regester()
		{
			System.out.println("Enter Mobile Number");
			long mobileNumber=s.nextLong();
			
			System.out.println("EnterUsername");
			userName=s.next();
			
			int j=0;
			while(j<=0)
			{
			System.out.println("EnterPassword");
			EnterPassword=s.next();
			
			System.out.println("ConformPassword");
			String ConformPassword=s.next();
			if(EnterPassword.equals(ConformPassword))
			{
				System.out.println("user created successfully");
				System.out.println("mobileno:"+mobileNumber);
				System.out.println("userName:"+userName);
				j++;
		      this.login();
			}
			else
			{
				System.out.println("Re enter pasword");
			}
	    }
	}
}